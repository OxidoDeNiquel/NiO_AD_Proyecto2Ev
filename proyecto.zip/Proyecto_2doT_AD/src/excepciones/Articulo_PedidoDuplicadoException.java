package excepciones;

public class Articulo_PedidoDuplicadoException extends Exception{
	public Articulo_PedidoDuplicadoException(String mensaje) {
        super(mensaje);
    }
}
